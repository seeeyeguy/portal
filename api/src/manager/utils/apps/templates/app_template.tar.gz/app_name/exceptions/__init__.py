"""
Error/Exception Module for `{{camel_case_app_name}}` Module.
"""


class {{camel_case_app_name}}Error(Exception):
    """Base Error for `{{camel_case_app_name}}`."""

    def __init__(self, message: str, status: int, *args: object) -> None:
        super().__init__(*args)
        self.message = message
        self.status = status

    def __str__(self) -> str:
        """String Representation of `{{camel_case_app_name}}` Error."""

        return f"{{camel_case_app_name}} Error (message={self.message}, status={self.status})"