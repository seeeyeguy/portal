from django.apps import AppConfig


class {{camel_case_app_name}}Config(AppConfig):
    """App Config for `{{camel_case_app_name}}` app."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "{{ app_name }}"
